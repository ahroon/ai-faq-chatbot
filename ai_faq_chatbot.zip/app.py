print('Welcome to the AI FAQ Chatbot')
# Add your chatbot logic here