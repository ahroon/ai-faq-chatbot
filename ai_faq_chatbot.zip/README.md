# AI FAQ Chatbot

This is a simple AI-powered FAQ chatbot built with Python.